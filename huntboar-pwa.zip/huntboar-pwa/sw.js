// Mise en cache pour jouer hors ligne. Change VERSION à chaque mise à jour du jeu.
const VERSION = 'huntboar-v1';
const FILES = [
  './', 'index.html', 'manifest.webmanifest',
  'js/main.js', 'js/world.js', 'js/boar.js', 'js/audio.js',
  'vendor/three.module.min.js',
  'icons/icon-180.png', 'icons/icon-192.png', 'icons/icon-512.png',
];
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k)))).then(() => self.clients.claim())
  );
});
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  e.respondWith(
    caches.match(e.request, { ignoreSearch: true }).then((hit) => hit || fetch(e.request))
  );
});
