// Sangliers : modèle, animation de course, comportement.
import * as THREE from '../vendor/three.module.min.js';
import { heightAt } from './world.js';

export const KINDS = {
  male: { label: 'Gros mâle', scale: 1.38, color: 0x64564b, points: 30, speed: 4.6, tusks: true },
  boar: { label: 'Sanglier', scale: 1.0, color: 0x7a6654, points: 10, speed: 4.4 },
  sow: { label: 'Laie meneuse', scale: 1.16, color: 0x857261, points: -50, speed: 4.2 },
  cub: { label: 'Marcassin', scale: 0.48, color: 0xcfa972, points: -70, speed: 4.2, stripes: true },
};

let shared = null;

function furTexture(stripes) {
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const g = c.getContext('2d');
  g.fillStyle = '#e2e2e2';
  g.fillRect(0, 0, 256, 256);
  if (stripes) {
    for (let i = 0; i < 5; i++) {
      g.fillStyle = 'rgba(60,40,25,0.75)';
      g.fillRect(18 + i * 26 + (i > 2 ? 100 : 0) * 0, 0, 9, 256);
    }
  }
  for (let i = 0; i < 5000; i++) {
    const x = Math.random() * 256, y = Math.random() * 256, l = 5 + Math.random() * 12;
    const v = Math.random();
    g.strokeStyle = v < 0.5 ? `rgba(40,34,30,${0.2 + Math.random() * 0.35})` : `rgba(240,230,215,${0.1 + Math.random() * 0.25})`;
    g.lineWidth = 0.8 + Math.random();
    g.beginPath();
    g.moveTo(x, y);
    g.lineTo(x + (Math.random() - 0.5) * 3, y - l);
    g.stroke();
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return t;
}

// Corps modelé par sections le long de l'échine : [z, yCentre, demi-largeur, demi-hauteur]
const STATIONS = [
  [-0.64, 0.6, 0.015, 0.015],
  [-0.6, 0.57, 0.11, 0.13],
  [-0.5, 0.555, 0.175, 0.2],
  [-0.32, 0.55, 0.215, 0.245],
  [-0.1, 0.55, 0.23, 0.26],
  [0.1, 0.575, 0.24, 0.295],
  [0.26, 0.6, 0.235, 0.32],
  [0.4, 0.595, 0.21, 0.3],
  [0.5, 0.56, 0.175, 0.25],
  [0.6, 0.5, 0.15, 0.2],
  [0.7, 0.445, 0.12, 0.15],
  [0.8, 0.4, 0.085, 0.1],
  [0.89, 0.37, 0.064, 0.07],
  [0.93, 0.36, 0.058, 0.062],
  [0.94, 0.36, 0.01, 0.01],
];

function bodyGeometry() {
  const R = 14, pos = [], uv = [], col = [], idx = [];
  STATIONS.forEach((s, i) => {
    for (let j = 0; j <= R; j++) {
      const a = (j / R) * Math.PI * 2 - Math.PI / 2;
      const cs = Math.cos(a), sn = Math.sin(a);
      // ventre plus plat, dos plus étroit
      const w = s[2] * (sn > 0 ? 1 - 0.25 * sn : 1);
      const h = s[3] * (sn < 0 ? 0.86 : 1);
      pos.push(cs * w, s[1] + sn * h, s[0]);
      uv.push((j / R) * 3, s[0] * 2.2);
      const snout = i >= 12 ? 0.55 : 1;
      const shade = (0.62 + 0.38 * (0.5 + 0.5 * sn)) * snout;
      col.push(shade, shade, shade);
    }
  });
  for (let i = 0; i < STATIONS.length - 1; i++) for (let j = 0; j < R; j++) {
    const a = i * (R + 1) + j, b = a + 1, c = a + R + 1, d = c + 1;
    idx.push(a, b, c, b, d, c);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

function maneGeometry() {
  const pos = [], idx = [];
  let n = 0;
  for (let i = 3; i <= 9; i++) {
    const s = STATIONS[i], top = s[1] + s[3] - 0.012;
    const hgt = i === 3 || i === 9 ? 0.012 : 0.06;
    pos.push(0, top, s[0], 0, top + hgt, s[0] - 0.02);
    if (n > 0) { const b = (n - 1) * 2; idx.push(b, b + 1, b + 2, b + 1, b + 3, b + 2); }
    n++;
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

function init() {
  const leg = new THREE.CylinderGeometry(0.075, 0.032, 0.46, 7, 1);
  leg.translate(0, -0.23, 0);
  shared = {
    body: bodyGeometry(),
    mane: maneGeometry(),
    leg,
    ear: new THREE.ConeGeometry(0.05, 0.13, 4),
    tusk: new THREE.ConeGeometry(0.014, 0.075, 5),
    tail: new THREE.CylinderGeometry(0.012, 0.006, 0.22, 4),
    fur: furTexture(false),
    furStripes: furTexture(true),
    dark: new THREE.MeshStandardMaterial({ color: 0x2a221d, roughness: 1 }),
    ivory: new THREE.MeshStandardMaterial({ color: 0xe8dfc8, roughness: 0.5 }),
    mats: {},
  };
  for (const k in KINDS) {
    const K = KINDS[k];
    shared.mats[k] = new THREE.MeshStandardMaterial({
      color: K.color, map: K.stripes ? shared.furStripes : shared.fur, bumpMap: shared.fur, bumpScale: 2,
      roughness: 0.95, metalness: 0, vertexColors: true,
    });
  }
}

export class Boar {
  constructor(kind) {
    if (!shared) init();
    const K = KINDS[kind];
    this.kind = kind;
    this.K = K;
    this.alive = true;
    this.wounded = false;
    this.penalized = false;
    this.alerted = false;
    this.baseSpeed = K.speed * (0.9 + Math.random() * 0.25);
    this.speed = this.baseSpeed;
    this.phase = Math.random() * 6;
    this.heading = 0;
    this.route = [];
    this.wp = 0;
    this.deadT = 0;
    this.group = new THREE.Group();
    this.group.scale.setScalar(K.scale * (0.94 + Math.random() * 0.12));
    this.torso = new THREE.Group();
    this.group.add(this.torso);

    const mat = shared.mats[kind];
    const body = new THREE.Mesh(shared.body, mat);
    body.userData.part = 'body';
    body.castShadow = true;
    this.torso.add(body);
    const mane = new THREE.Mesh(shared.mane, shared.dark);
    mane.material.side = THREE.DoubleSide;
    this.torso.add(mane);
    for (const sx of [-1, 1]) {
      const ear = new THREE.Mesh(shared.ear, mat);
      ear.position.set(sx * 0.1, 0.79, 0.52);
      ear.rotation.set(-0.35, 0, -sx * 0.35);
      this.torso.add(ear);
      if (K.tusks) {
        const tusk = new THREE.Mesh(shared.tusk, shared.ivory);
        tusk.position.set(sx * 0.068, 0.385, 0.84);
        tusk.rotation.set(0.5, 0, -sx * 0.5);
        this.torso.add(tusk);
      }
    }
    const tail = new THREE.Mesh(shared.tail, shared.dark);
    tail.position.set(0, 0.56, -0.66);
    tail.rotation.x = -0.5;
    this.torso.add(tail);

    this.legs = [];
    const spots = [[0.13, 0.3], [-0.13, 0.3], [0.13, -0.42], [-0.13, -0.42]];
    spots.forEach((s, i) => {
      const leg = new THREE.Mesh(shared.leg, shared.dark);
      leg.position.set(s[0], 0.45, s[1]);
      leg.userData.part = 'leg';
      leg.castShadow = true;
      this.group.add(leg);
      this.legs.push(leg);
    });
    this.group.traverse((o) => { o.userData.boar = this; });
  }

  place(x, z) {
    this.group.position.set(x, heightAt(x, z), z);
  }

  setRoute(points) {
    this.route = points;
    this.wp = 0;
    const p = points[0];
    this.heading = Math.atan2(p.x - this.group.position.x, p.z - this.group.position.z);
    this.group.rotation.y = this.heading;
  }

  // Fuite au coup de feu : accélère et change de direction
  alert() {
    if (!this.alive || this.alerted) return;
    this.alerted = true;
    this.speed = Math.min(10.5, this.baseSpeed * (1.9 + Math.random() * 0.4)) * (this.wounded ? 0.55 : 1);
    const pos = this.group.position;
    let a = this.heading + (Math.random() < 0.5 ? -1 : 1) * (0.5 + Math.random() * 0.8);
    // ne pas foncer sur le mirador
    const toStand = Math.atan2(-pos.x, -pos.z);
    let diff = Math.atan2(Math.sin(a - toStand), Math.cos(a - toStand));
    if (Math.abs(diff) < 0.6) a = toStand + Math.sign(diff || 1) * 0.9;
    this.route = [
      { x: pos.x + Math.sin(a) * 45, z: pos.z + Math.cos(a) * 45 },
      { x: pos.x + Math.sin(a) * 220, z: pos.z + Math.cos(a) * 220 },
    ];
    this.wp = 0;
  }

  wound() {
    this.wounded = true;
    this.speed *= 0.55;
  }

  kill() {
    this.alive = false;
    this.deadT = 0;
    this.fallSide = Math.random() < 0.5 ? -1 : 1;
  }

  // Renvoie false quand l'animal doit être retiré de la scène
  update(dt, world) {
    const g = this.group, pos = g.position;
    if (!this.alive) {
      this.deadT += dt;
      const t = Math.min(1, this.deadT / 0.45);
      const k = 1 - (1 - t) * (1 - t);
      g.rotation.z = this.fallSide * k * 1.45;
      const slide = this.speed * Math.max(0, 1 - this.deadT * 1.6) * dt;
      pos.x += Math.sin(this.heading) * slide;
      pos.z += Math.cos(this.heading) * slide;
      pos.y = heightAt(pos.x, pos.z) + k * 0.2 * g.scale.x;
      for (const l of this.legs) l.rotation.x *= 0.9;
      return this.deadT < 30;
    }
    const target = this.route[this.wp];
    if (!target) return false;
    const dx = target.x - pos.x, dz = target.z - pos.z, dist = Math.hypot(dx, dz);
    if (dist < 3) {
      this.wp++;
      if (this.wp >= this.route.length) return false;
    }
    const want = Math.atan2(dx, dz);
    let diff = Math.atan2(Math.sin(want - this.heading), Math.cos(want - this.heading));
    const turn = 2.6 * dt;
    this.heading += Math.max(-turn, Math.min(turn, diff));
    pos.x += Math.sin(this.heading) * this.speed * dt;
    pos.z += Math.cos(this.heading) * this.speed * dt;
    world.pushOut(pos, 0.35 * g.scale.x);
    // garder ses distances avec le mirador
    const r = Math.hypot(pos.x, pos.z);
    if (r < 6) { pos.x *= 6 / r; pos.z *= 6 / r; }
    g.rotation.y = this.heading;

    // course : antérieurs et postérieurs en opposition, avec un léger décalage gauche/droite
    const stride = this.speed / (1.15 * g.scale.x);
    this.phase += dt * stride * 2.1;
    const amp = Math.min(0.95, 0.3 + this.speed * 0.075) * (this.wounded ? 0.6 : 1);
    const ph = this.phase;
    this.legs[0].rotation.x = Math.sin(ph) * amp;
    this.legs[1].rotation.x = Math.sin(ph + 0.55) * amp;
    this.legs[2].rotation.x = Math.sin(ph + Math.PI) * amp;
    this.legs[3].rotation.x = Math.sin(ph + Math.PI + 0.55) * amp;
    const bob = Math.abs(Math.sin(ph + 0.3));
    this.torso.position.y = bob * 0.05 * (amp / 0.8);
    this.torso.rotation.x = Math.sin(ph + 0.8) * 0.07 * (amp / 0.8) + (this.wounded ? 0.08 : 0);
    pos.y = heightAt(pos.x, pos.z);
    return r < 235;
  }
}
