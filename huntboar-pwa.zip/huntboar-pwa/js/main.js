// HuntBoar — boucle de jeu, visée, tir, vagues, score.
import * as THREE from '../vendor/three.module.min.js';
import { buildWorld, heightAt, NEIGHBOURS } from './world.js';
import { Boar, KINDS } from './boar.js';
import * as sfx from './audio.js';

const $ = (id) => document.getElementById(id);
const HUNT_DURATION = 240, MAX_AMMO = 10, AMMO_REGEN = 1.5, BOLT_TIME = 1.2, EYE_HEIGHT = 3.9;
const RECORD_KEY = 'huntboar.record.foret';

// ---------- Rendu ----------
const canvas = $('c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
let pixelRatio = Math.min(window.devicePixelRatio || 1, 2);
renderer.setPixelRatio(pixelRatio);
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 0.95;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(52, 1, 0.06, 1200);
camera.rotation.order = 'YXZ';
camera.position.set(0, EYE_HEIGHT, 0);
scene.add(camera);

const world = buildWorld(scene, renderer);

// ---------- Carabine ----------
const rifle = new THREE.Group();
const REST = new THREE.Vector3(0.2, -0.2, -0.5);
{
  const walnut = new THREE.MeshStandardMaterial({ color: 0x4a2c17, roughness: 0.55 });
  const steel = new THREE.MeshStandardMaterial({ color: 0x1c1e21, roughness: 0.42, metalness: 0.35 });
  const add = (geo, mat, x, y, z, rx) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    if (rx) m.rotation.x = rx;
    rifle.add(m);
    return m;
  };
  const H = Math.PI / 2;
  add(new THREE.BoxGeometry(0.046, 0.085, 0.4), walnut, 0, -0.04, 0.2, -0.1);
  add(new THREE.BoxGeometry(0.044, 0.05, 0.36), walnut, 0, -0.012, -0.18);
  add(new THREE.BoxGeometry(0.038, 0.046, 0.22), steel, 0, 0.014, -0.02);
  add(new THREE.CylinderGeometry(0.0105, 0.012, 0.66, 10), steel, 0, 0.02, -0.45, H);
  add(new THREE.CylinderGeometry(0.0135, 0.0135, 0.3, 14), steel, 0, 0.062, -0.05, H);
  add(new THREE.CylinderGeometry(0.021, 0.015, 0.08, 14), steel, 0, 0.062, -0.235, H);
  add(new THREE.CylinderGeometry(0.017, 0.019, 0.06, 14), steel, 0, 0.062, 0.115, H);
  add(new THREE.CylinderGeometry(0.006, 0.006, 0.05, 6), steel, 0.04, 0.02, 0.03).rotation.z = H;
  add(new THREE.SphereGeometry(0.011, 8, 6), steel, 0.066, 0.02, 0.03);
}
rifle.position.copy(REST);
camera.add(rifle);
const muzzleLight = new THREE.PointLight(0xffc27a, 0, 14);
muzzleLight.position.set(0.17, -0.1, -1.2);
camera.add(muzzleLight);

// ---------- Poussière d'impact ----------
const puffTex = (() => {
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  const g = c.getContext('2d');
  const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  gr.addColorStop(0, 'rgba(255,255,255,0.9)');
  gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr;
  g.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(c);
})();
const puffs = [];
for (let i = 0; i < 8; i++) {
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: puffTex, transparent: true, depthWrite: false, opacity: 0 }));
  s.visible = false;
  scene.add(s);
  puffs.push({ s, life: 0 });
}
function puff(point, color, size) {
  const p = puffs.find((q) => q.life <= 0) || puffs[0];
  p.s.position.copy(point);
  p.s.material.color.set(color);
  p.size = size;
  p.life = 0.6;
  p.s.visible = true;
}

// ---------- État ----------
let mode = 'menu';
let yaw = 0, pitch = -0.08, recoil = 0;
let scoped = false, zoom = 4;
let ammo = MAX_AMMO, ammoTimer = 0, bolt = 0;
let timeLeft = HUNT_DURATION, waveTimer = 3;
let boars = [];
let stats;
let lastHud = '';

function resetStats() {
  stats = { score: 0, shots: 0, hits: 0, kills: { male: 0, boar: 0, sow: 0, cub: 0 }, bonus: {}, bonusPts: 0, penalty: 0, danger: 0, streak: 0, chain: 0, lastKill: -99 };
}
resetStats();

function getRecord() {
  try { return parseInt(localStorage.getItem(RECORD_KEY) || '0', 10) || 0; } catch (e) { return 0; }
}
function setRecord(v) {
  try { localStorage.setItem(RECORD_KEY, String(v)); } catch (e) { /* stockage indisponible */ }
}

// ---------- Interface ----------
function toast(text, cls) {
  const d = document.createElement('div');
  d.className = 'toast ' + (cls || '');
  d.textContent = text;
  $('toasts').appendChild(d);
  setTimeout(() => d.remove(), 1900);
}
function addBonus(name, pts) {
  stats.score += pts;
  stats.bonusPts += pts;
  stats.bonus[name] = (stats.bonus[name] || 0) + 1;
  toast(name + ' +' + pts, 'good');
}
function setScoped(v) {
  scoped = v;
  $('scope').hidden = !v;
  $('fireBtn').hidden = !v;
  $('zoomWrap').hidden = !v;
  $('scopeBtn').classList.toggle('on', v);
  rifle.visible = !v;
}
function baseFov() {
  return innerWidth >= innerHeight ? 52 : 78;
}
function resize() {
  renderer.setSize(innerWidth, innerHeight, false);
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
}
addEventListener('resize', resize);
resize();

// ---------- Visée ----------
let aimId = null, lastX = 0, lastY = 0, downX = 0, downY = 0, downT = 0;
canvas.addEventListener('pointerdown', (e) => {
  if (aimId !== null) return;
  aimId = e.pointerId;
  lastX = downX = e.clientX;
  lastY = downY = e.clientY;
  downT = performance.now();
  canvas.setPointerCapture(e.pointerId);
});
canvas.addEventListener('pointermove', (e) => {
  if (e.pointerId !== aimId || mode !== 'play') return;
  const k = 0.0042 * (camera.fov / 52);
  yaw -= (e.clientX - lastX) * k;
  pitch = Math.max(-0.95, Math.min(0.6, pitch - (e.clientY - lastY) * k));
  lastX = e.clientX;
  lastY = e.clientY;
});
const endAim = (e) => {
  if (e.pointerId !== aimId) return;
  aimId = null;
  const moved = Math.hypot(e.clientX - downX, e.clientY - downY);
  if (e.type === 'pointerup' && mode === 'play' && !scoped && moved < 10 && performance.now() - downT < 350) fire();
};
canvas.addEventListener('pointerup', endAim);
canvas.addEventListener('pointercancel', endAim);
$('scopeBtn').addEventListener('click', () => { if (mode === 'play') setScoped(!scoped); });
$('fireBtn').addEventListener('pointerdown', (e) => { e.preventDefault(); fire(); });
$('zoom').addEventListener('input', (e) => { zoom = parseFloat(e.target.value); $('zoomVal').textContent = '×' + zoom; });
addEventListener('keydown', (e) => {
  if (mode !== 'play') return;
  if (e.code === 'Space') fire();
  if (e.code === 'KeyZ' || e.code === 'ShiftLeft') setScoped(!scoped);
});

// ---------- Tir ----------
const raycaster = new THREE.Raycaster();
const _o = new THREE.Vector3(), _d = new THREE.Vector3(), _p = new THREE.Vector3();

function fire() {
  if (mode !== 'play' || bolt > 0) return;
  if (ammo <= 0) { sfx.playEmpty(); toast('Plus de balles', 'bad'); return; }
  ammo--;
  bolt = BOLT_TIME;
  stats.shots++;
  sfx.playShot();
  camera.updateMatrixWorld(true);
  camera.getWorldPosition(_o);
  camera.getWorldDirection(_d);
  if (!scoped) {
    // sans épauler, le tir se disperse
    const a = Math.random() * Math.PI * 2, r = Math.random() * 0.022;
    _d.x += Math.cos(a) * r; _d.y += Math.sin(a) * r * 0.7; _d.z += Math.sin(a) * r;
    _d.normalize();
  }
  recoil += scoped ? 0.03 : 0.05;
  muzzleLight.intensity = 60;
  $('flash').classList.remove('go');
  void $('flash').offsetWidth;
  $('flash').classList.add('go');

  const block = world.rayBlock(_o, _d, 400);
  raycaster.set(_o, _d);
  raycaster.far = block.dist;
  const targets = boars.filter((b) => b.alive).map((b) => b.group);
  let hit = null;
  for (const h of raycaster.intersectObjects(targets, true)) {
    if (h.object.userData.part) { hit = h; break; }
  }
  if (hit) {
    handleHit(hit);
  } else {
    stats.streak = 0;
    if (block.kind !== 'none') {
      _p.copy(_o).addScaledVector(_d, block.dist - 0.1);
      puff(_p, block.kind === 'tree' ? 0x8a7a66 : 0x6b5a40, block.kind === 'tree' ? 0.7 : 1.3);
    }
  }
  checkDanger();
  for (const b of boars) b.alert();
}

function handleHit(hit) {
  const b = hit.object.userData.boar, K = b.K;
  stats.hits++;
  stats.streak++;
  sfx.playHit();
  puff(hit.point, 0x5a1410, 0.5 * b.group.scale.x + 0.3);
  const local = b.group.worldToLocal(hit.point.clone());
  const front = hit.object.userData.part === 'body' && local.z > -0.06;
  const wasWounded = b.wounded;
  if (K.points < 0 && !b.penalized) {
    b.penalized = true;
    stats.score += K.points;
    stats.penalty += K.points;
    sfx.playPenalty();
    toast(K.label + ' ' + K.points, 'bad');
  }
  if (front || wasWounded) {
    b.kill();
    stats.kills[b.kind]++;
    if (K.points > 0) {
      stats.score += K.points;
      toast(K.label + ' +' + K.points, 'good');
      if (!wasWounded) addBonus('Une seule balle', 5);
      if (hit.distance >= 80) addBonus('Tir lointain', 10);
      const now = HUNT_DURATION - timeLeft;
      stats.chain = now - stats.lastKill < 4 ? stats.chain + 1 : 1;
      stats.lastKill = now;
      if (stats.chain === 2) addBonus('Doublé', 15);
      if (stats.chain === 3) addBonus('Triplé', 30);
    }
  } else {
    b.wound();
    toast('Blessé : il faut une 2ᵉ balle');
  }
  if (stats.streak >= 5) { stats.streak = 0; addBonus('Série de 5', 20); }
}

// Tir dangereux : la balle passe à moins de 10 m d'un voisin (sans compter les arbres)
function checkDanger() {
  let len = 400;
  for (let t = 1; t < 400; t += 1) {
    if (_o.y + _d.y * t < heightAt(_o.x + _d.x * t, _o.z + _d.z * t)) { len = t; break; }
  }
  for (const n of NEIGHBOURS) {
    _p.set(n.x, heightAt(n.x, n.z) + 3.6, n.z).sub(_o);
    const t = Math.max(0, Math.min(len, _p.dot(_d)));
    const dx = _o.x + _d.x * t - n.x, dy = _o.y + _d.y * t - (heightAt(n.x, n.z) + 3.6), dz = _o.z + _d.z * t - n.z;
    if (Math.hypot(dx, dy, dz) < 10) {
      stats.score -= 100;
      stats.danger++;
      sfx.playPenalty();
      toast('Tir dangereux vers un voisin −100', 'bad');
      return;
    }
  }
}

// ---------- Vagues ----------
const rnd = (a, b) => a + Math.random() * (b - a);

function spawnWave() {
  if (boars.filter((b) => b.alive).length > 15) return;
  const r = Math.random();
  let kinds;
  if (r < 0.2) kinds = ['male'];
  else if (r < 0.48) {
    kinds = ['sow'];
    const n = 2 + ((Math.random() * 4) | 0);
    for (let i = 0; i < n; i++) kinds.push('cub');
    if (Math.random() < 0.4) kinds.push('boar');
  } else {
    kinds = [];
    const n = 2 + ((Math.random() * 5) | 0);
    for (let i = 0; i < n; i++) kinds.push('boar');
  }
  const th = rnd(-1.25, 1.25), R = rnd(132, 148);
  const x0 = Math.sin(th) * R, z0 = -Math.cos(th) * R;
  let x2 = rnd(-40, 40), z2 = rnd(-50, -13);
  if (Math.hypot(x2, z2) < 13) z2 = -16;
  const w1 = { x: x0 * 0.5 + rnd(-22, 22), z: rnd(-78, -55) };
  let w3;
  if (Math.random() < 0.55) w3 = { x: x2 + rnd(-70, 70) + Math.sign(x2 || 1) * 30, z: rnd(120, 180) };
  else w3 = { x: (Math.random() < 0.5 ? -1 : 1) * rnd(160, 200), z: rnd(-110, -10) };
  // contourner le mirador si le trajet final passe trop près
  const mid = { x: x2 + Math.sign(x2 || 1) * 14, z: 4 };
  const route = w3.z > 0 ? [w1, { x: x2, z: z2 }, mid, w3] : [w1, { x: x2, z: z2 }, w3];
  const dirx = x0 / R, dirz = z0 / R;
  const speed = rnd(3.6, 5.2);
  kinds.forEach((kind, i) => {
    const b = new Boar(kind);
    const ox = i === 0 ? 0 : rnd(-2.6, 2.6), back = i * rnd(1.6, 2.6);
    b.place(x0 + ox + dirx * back, z0 + dirz * back);
    b.baseSpeed = speed * (kind === 'cub' ? 1 : rnd(0.96, 1.04));
    b.speed = b.baseSpeed;
    b.setRoute(route.map((p) => ({ x: p.x + ox, z: p.z + rnd(-1, 1) })));
    scene.add(b.group);
    boars.push(b);
  });
}

// ---------- Partie ----------
function startHunt() {
  sfx.initAudio();
  for (const b of boars) scene.remove(b.group);
  boars = [];
  resetStats();
  ammo = MAX_AMMO; ammoTimer = 0; bolt = 0;
  timeLeft = HUNT_DURATION; waveTimer = 2.5;
  yaw = 0; pitch = -0.1; recoil = 0;
  setScoped(false);
  $('menu').hidden = true;
  $('end').hidden = true;
  $('hud').hidden = false;
  mode = 'play';
}

function endHunt() {
  mode = 'end';
  setScoped(false);
  $('hud').hidden = true;
  const rec = getRecord(), isRec = stats.score > rec;
  if (isRec) setRecord(stats.score);
  const acc = stats.shots ? Math.round((stats.hits / stats.shots) * 100) : 0;
  const rows = [];
  const row = (a, b, cls) => rows.push(`<tr class="${cls || ''}"><td>${a}</td><td>${b}</td></tr>`);
  for (const k of ['male', 'boar', 'sow', 'cub']) {
    const n = stats.kills[k];
    if (n) row(`${KINDS[k].label} × ${n}`, (KINDS[k].points > 0 ? '+' : '') + n * KINDS[k].points, KINDS[k].points < 0 ? 'bad' : '');
  }
  if (!rows.length) row('Aucun animal au tableau', '0');
  for (const name in stats.bonus) row(`${name} × ${stats.bonus[name]}`, '');
  if (stats.bonusPts) row('Total des bonus', '+' + stats.bonusPts, 'good');
  if (stats.danger) row(`Tir dangereux × ${stats.danger}`, '−' + stats.danger * 100, 'bad');
  row('Précision', `${acc} % (${stats.hits}/${stats.shots})`);
  $('endBody').innerHTML = rows.join('');
  $('endScore').textContent = stats.score;
  $('endRecord').textContent = isRec ? 'Nouveau record !' : 'Record : ' + rec;
  $('end').hidden = false;
}

$('start').addEventListener('click', startHunt);
$('again').addEventListener('click', startHunt);
$('toMenu').addEventListener('click', () => {
  $('end').hidden = true;
  $('menu').hidden = false;
  $('record').textContent = getRecord() ? 'Record : ' + getRecord() : '';
  mode = 'menu';
});
$('record').textContent = getRecord() ? 'Record : ' + getRecord() : '';

// ---------- Boucle ----------
let last = performance.now(), slow = 0, fast = 0, elapsed = 0;

function frame(now) {
  requestAnimationFrame(frame);
  const raw = (now - last) / 1000;
  last = now;
  const dt = Math.min(raw, 0.05);
  elapsed += dt;

  // qualité adaptative : on baisse la résolution, puis les ombres, si l'appareil peine
  if (raw > 0.026 && raw < 0.5) { slow += raw; fast = 0; } else { fast += raw; if (fast > 3) slow = 0; }
  if (slow > 2.5) {
    slow = 0;
    if (pixelRatio > 1) { pixelRatio = Math.max(1, pixelRatio - 0.25); renderer.setPixelRatio(pixelRatio); resize(); }
    else if (renderer.shadowMap.enabled) { world.sun.castShadow = false; renderer.shadowMap.enabled = false; }
  }

  if (mode === 'play') {
    timeLeft -= dt;
    if (ammo < MAX_AMMO) {
      ammoTimer += dt;
      if (ammoTimer >= AMMO_REGEN) { ammoTimer = 0; ammo++; }
    } else ammoTimer = 0;
    if (bolt > 0) bolt = Math.max(0, bolt - dt);
    waveTimer -= dt;
    if (waveTimer <= 0 && timeLeft > 8) { spawnWave(); waveTimer = rnd(7, 13); }
    if (timeLeft <= 0) endHunt();
  } else if (mode === 'menu') {
    yaw = Math.sin(elapsed * 0.05) * 0.5;
    pitch = -0.06;
  }

  if (mode !== 'menu') {
    for (let i = boars.length - 1; i >= 0; i--) {
      if (!boars[i].update(dt, world)) { scene.remove(boars[i].group); boars.splice(i, 1); }
    }
  }

  // caméra
  recoil -= recoil * Math.min(1, 9 * dt);
  muzzleLight.intensity *= Math.max(0, 1 - 30 * dt);
  const targetFov = scoped ? baseFov() / zoom : baseFov();
  if (Math.abs(camera.fov - targetFov) > 0.01) {
    camera.fov += (targetFov - camera.fov) * Math.min(1, 18 * dt);
    camera.updateProjectionMatrix();
  }
  const sway = scoped ? 1 : 0.35;
  camera.rotation.set(
    pitch + recoil + Math.sin(elapsed * 1.1) * 0.0014 * sway,
    yaw + Math.cos(elapsed * 0.8) * 0.0017 * sway,
    0
  );
  // carabine : recul puis manœuvre de la culasse
  const cyc = bolt > 0 ? 1 - bolt / BOLT_TIME : 1;
  const work = cyc > 0.3 && cyc < 0.95 ? Math.sin(((cyc - 0.3) / 0.65) * Math.PI) : 0;
  rifle.position.set(REST.x + work * 0.012, REST.y - work * 0.02 + Math.sin(elapsed * 1.3) * 0.0015, REST.z + recoil * 1.6);
  rifle.rotation.set(recoil * 1.2 - work * 0.06, work * 0.05, -work * 0.28);

  for (const p of puffs) {
    if (p.life <= 0) continue;
    p.life -= dt;
    const t = 1 - p.life / 0.6;
    p.s.scale.setScalar(p.size * (0.4 + t * 1.6));
    p.s.material.opacity = 0.75 * (1 - t);
    p.s.position.y += dt * 0.5;
    if (p.life <= 0) p.s.visible = false;
  }

  if (mode === 'play') {
    const tl = Math.max(0, Math.ceil(timeLeft));
    const hud = tl + '|' + stats.score + '|' + ammo + '|' + (bolt > 0);
    if (hud !== lastHud) {
      lastHud = hud;
      $('time').textContent = Math.floor(tl / 60) + ':' + String(tl % 60).padStart(2, '0');
      $('score').textContent = stats.score;
      $('ammo').textContent = '▮'.repeat(ammo) + '▯'.repeat(MAX_AMMO - ammo);
      $('ammo').classList.toggle('busy', bolt > 0);
      $('fireBtn').classList.toggle('busy', bolt > 0 || ammo === 0);
    }
  }
  renderer.render(scene, camera);
}
requestAnimationFrame(frame);

// Accès pour les essais
window.__hb = { camera, scene, startHunt, spawnWave, fire, setScoped, get boars() { return boars; }, set aim(v) { yaw = v[0]; pitch = v[1]; }, get stats() { return stats; }, renderer };
if (new URLSearchParams(location.search).has('auto')) startHunt();
