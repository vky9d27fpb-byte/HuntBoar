// Sons fabriqués en code (aucun fichier audio à charger).
let ctx = null, master = null, noiseBuf = null;

export function initAudio() {
  if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return;
  ctx = new AC();
  master = ctx.createGain();
  master.gain.value = 0.9;
  master.connect(ctx.destination);
  noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
  const d = noiseBuf.getChannelData(0);
  for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  // vent dans les arbres
  const wind = ctx.createBufferSource();
  wind.buffer = noiseBuf;
  wind.loop = true;
  const bp = ctx.createBiquadFilter();
  bp.type = 'bandpass';
  bp.frequency.value = 420;
  bp.Q.value = 0.4;
  const wg = ctx.createGain();
  wg.gain.value = 0.035;
  const lfo = ctx.createOscillator();
  lfo.frequency.value = 0.11;
  const lg = ctx.createGain();
  lg.gain.value = 0.02;
  lfo.connect(lg).connect(wg.gain);
  wind.connect(bp).connect(wg).connect(master);
  wind.start();
  lfo.start();
}

function burst(t, dur, freq, type, gain, q) {
  const src = ctx.createBufferSource();
  src.buffer = noiseBuf;
  const f = ctx.createBiquadFilter();
  f.type = type;
  f.frequency.value = freq;
  f.Q.value = q || 0.7;
  const g = ctx.createGain();
  g.gain.setValueAtTime(gain, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  src.connect(f).connect(g).connect(master);
  src.start(t, Math.random());
  src.stop(t + dur + 0.05);
  return f;
}

export function playShot() {
  if (!ctx) return;
  const t = ctx.currentTime;
  const f = burst(t, 0.35, 5200, 'lowpass', 1.0);
  f.frequency.exponentialRampToValueAtTime(500, t + 0.3);
  // souffle grave
  const o = ctx.createOscillator();
  o.frequency.setValueAtTime(130, t);
  o.frequency.exponentialRampToValueAtTime(38, t + 0.25);
  const og = ctx.createGain();
  og.gain.setValueAtTime(0.9, t);
  og.gain.exponentialRampToValueAtTime(0.0001, t + 0.3);
  o.connect(og).connect(master);
  o.start(t);
  o.stop(t + 0.32);
  // écho de la forêt
  burst(t + 0.16, 1.5, 900, 'lowpass', 0.22);
  burst(t + 0.42, 1.9, 480, 'lowpass', 0.12);
  // culasse
  burst(t + 0.45, 0.05, 2600, 'bandpass', 0.25, 3);
  burst(t + 0.62, 0.04, 3400, 'bandpass', 0.2, 3);
  burst(t + 0.95, 0.06, 2200, 'bandpass', 0.28, 3);
}

export function playHit() {
  if (!ctx) return;
  burst(ctx.currentTime + 0.05, 0.18, 260, 'lowpass', 0.5);
}

export function playEmpty() {
  if (!ctx) return;
  burst(ctx.currentTime, 0.04, 3000, 'bandpass', 0.2, 4);
}

export function playPenalty() {
  if (!ctx) return;
  const t = ctx.currentTime;
  for (let i = 0; i < 2; i++) {
    const o = ctx.createOscillator();
    o.type = 'square';
    o.frequency.value = i ? 150 : 200;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.12, t + i * 0.18);
    g.gain.exponentialRampToValueAtTime(0.0001, t + i * 0.18 + 0.16);
    o.connect(g).connect(master);
    o.start(t + i * 0.18);
    o.stop(t + i * 0.18 + 0.2);
  }
}
