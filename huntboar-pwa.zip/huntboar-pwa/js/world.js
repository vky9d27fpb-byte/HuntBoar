// Décor : ciel, lumière, sol, forêt, mirador, voisins.
import * as THREE from '../vendor/three.module.min.js';

const V3 = THREE.Vector3;

export function makeRng(seed) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function smoothstep(a, b, x) {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
}

// Relief doux, plat autour du mirador
export function heightAt(x, z) {
  const r = Math.hypot(x, z);
  const h =
    1.6 * Math.sin(x * 0.021 + 1.3) * Math.cos(z * 0.017 + 0.4) +
    0.7 * Math.sin(x * 0.053 + z * 0.041) +
    0.22 * Math.sin(x * 0.13 - z * 0.11);
  return h * smoothstep(5, 32, r);
}

export const NEIGHBOURS = [
  { x: -70, z: 0 },
  { x: 70, z: 0 },
];

function canvasTexture(size, h, draw, repeat) {
  const c = document.createElement('canvas');
  c.width = size;
  c.height = h;
  draw(c.getContext('2d'), size, h);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  if (repeat) t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return t;
}

// ---------- Textures dessinées ----------

function groundTexture(rand) {
  return canvasTexture(1024, 1024, (g, s) => {
    g.fillStyle = '#342a1e';
    g.fillRect(0, 0, s, s);
    // taches d'humus
    for (let i = 0; i < 260; i++) {
      const x = rand() * s, y = rand() * s, r = 30 + rand() * 90;
      const dark = rand() < 0.5;
      for (const ox of [0, -s, s]) for (const oy of [0, -s, s]) {
        const gr = g.createRadialGradient(x + ox, y + oy, 0, x + ox, y + oy, r);
        gr.addColorStop(0, dark ? 'rgba(20,16,10,0.35)' : 'rgba(96,78,48,0.28)');
        gr.addColorStop(1, 'rgba(0,0,0,0)');
        g.fillStyle = gr;
        g.fillRect(x + ox - r, y + oy - r, r * 2, r * 2);
      }
    }
    // feuilles mortes
    const palette = ['#5e4527', '#6a4d2a', '#4e3820', '#755a34', '#41321f', '#7c6036', '#33271a', '#86683e', '#524028', '#4a4126'];
    for (let i = 0; i < 15000; i++) {
      const x = rand() * s, y = rand() * s;
      const w = 5 + rand() * 9, h = w * (0.45 + rand() * 0.3), a = rand() * Math.PI;
      g.fillStyle = palette[(rand() * palette.length) | 0];
      g.globalAlpha = 0.75 + rand() * 0.25;
      for (const ox of [0, x < 20 ? s : x > s - 20 ? -s : null]) {
        if (ox === null) continue;
        for (const oy of [0, y < 20 ? s : y > s - 20 ? -s : null]) {
          if (oy === null) continue;
          g.beginPath();
          g.ellipse(x + ox, y + oy, w, h, a, 0, Math.PI * 2);
          g.fill();
          g.strokeStyle = 'rgba(25,18,10,0.35)';
          g.lineWidth = 0.7;
          g.beginPath();
          g.moveTo(x + ox - Math.cos(a) * w, y + oy - Math.sin(a) * w);
          g.lineTo(x + ox + Math.cos(a) * w, y + oy + Math.sin(a) * w);
          g.stroke();
        }
      }
    }
    g.globalAlpha = 1;
    // brindilles
    for (let i = 0; i < 260; i++) {
      const x = rand() * s, y = rand() * s, a = rand() * Math.PI * 2, l = 15 + rand() * 50;
      g.strokeStyle = rand() < 0.5 ? '#231a10' : '#57452e';
      g.lineWidth = 1 + rand() * 1.6;
      g.beginPath();
      g.moveTo(x, y);
      g.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l);
      g.stroke();
    }
  }, true);
}

function barkTexture(rand) {
  return canvasTexture(256, 512, (g, w, h) => {
    g.fillStyle = '#5b5248';
    g.fillRect(0, 0, w, h);
    for (let i = 0; i < 900; i++) {
      const x = rand() * w, y = rand() * h, l = 20 + rand() * 120;
      const v = rand();
      g.strokeStyle = v < 0.55 ? `rgba(22,18,14,${0.25 + rand() * 0.45})` : `rgba(150,140,122,${0.1 + rand() * 0.25})`;
      g.lineWidth = 1 + rand() * 3;
      g.beginPath();
      g.moveTo(x, y);
      g.bezierCurveTo(x + (rand() - 0.5) * 8, y + l * 0.3, x + (rand() - 0.5) * 8, y + l * 0.6, x + (rand() - 0.5) * 6, y + l);
      g.stroke();
      if (y + l > h) {
        g.beginPath();
        g.moveTo(x, y - h);
        g.lineTo(x, y + l - h);
        g.stroke();
      }
    }
    // lichen et mousse
    for (let i = 0; i < 90; i++) {
      const x = rand() * w, y = rand() * h, r = 4 + rand() * 16;
      g.fillStyle = rand() < 0.5 ? 'rgba(150,160,130,0.22)' : 'rgba(70,90,45,0.25)';
      g.beginPath();
      g.ellipse(x, y, r, r * (0.5 + rand()), rand() * 3, 0, Math.PI * 2);
      g.fill();
    }
  }, true);
}

function twigTexture(rand) {
  return canvasTexture(256, 256, (g, s) => {
    g.clearRect(0, 0, s, s);
    g.lineCap = 'round';
    const grow = (x, y, a, len, w, d) => {
      const x2 = x + Math.cos(a) * len, y2 = y + Math.sin(a) * len;
      g.strokeStyle = d > 2 ? '#3a3028' : '#2a221c';
      g.lineWidth = w;
      g.beginPath();
      g.moveTo(x, y);
      g.lineTo(x2, y2);
      g.stroke();
      if (d >= 5) return;
      const n = 2 + ((rand() * 2) | 0);
      for (let i = 0; i < n; i++) grow(x2, y2, a + (rand() - 0.5) * 1.5, len * (0.62 + rand() * 0.2), Math.max(0.8, w * 0.62), d + 1);
      if (rand() < 0.7) grow(x + (x2 - x) * 0.5, y + (y2 - y) * 0.5, a + (rand() < 0.5 ? -1 : 1) * (0.5 + rand() * 0.6), len * 0.55, Math.max(0.8, w * 0.5), d + 2);
    };
    grow(s / 2, s, -Math.PI / 2, 62, 5, 0);
  }, false);
}

function grassTexture(rand) {
  return canvasTexture(256, 256, (g, s) => {
    g.clearRect(0, 0, s, s);
    g.lineCap = 'round';
    const cols = ['#85724a', '#978458', '#6e603a', '#a8976a', '#5f5e36', '#50562e', '#7a6842'];
    for (let i = 0; i < 150; i++) {
      const x = 20 + rand() * (s - 40), h = 70 + rand() * 170, lean = (rand() - 0.5) * 110;
      g.strokeStyle = cols[(rand() * cols.length) | 0];
      g.lineWidth = 1.2 + rand() * 2.4;
      g.beginPath();
      g.moveTo(x, s);
      g.quadraticCurveTo(x + lean * 0.2, s - h * 0.6, x + lean, s - h);
      g.stroke();
    }
  }, false);
}

function fernTexture(rand) {
  return canvasTexture(256, 256, (g, s) => {
    g.clearRect(0, 0, s, s);
    g.lineCap = 'round';
    for (let f = 0; f < 9; f++) {
      const a0 = -Math.PI / 2 + (f - 4) * 0.27 + (rand() - 0.5) * 0.15;
      const len = 150 + rand() * 80;
      const col = rand() < 0.6 ? [112, 76, 40] : [96, 82, 44];
      let x = s / 2, y = s - 2, a = a0;
      for (let i = 0; i < 26; i++) {
        const t = i / 26, st = len / 26;
        const nx = x + Math.cos(a) * st, ny = y + Math.sin(a) * st;
        g.strokeStyle = `rgb(${col[0] * 0.55},${col[1] * 0.55},${col[2] * 0.55})`;
        g.lineWidth = 2.2 * (1 - t) + 0.6;
        g.beginPath(); g.moveTo(x, y); g.lineTo(nx, ny); g.stroke();
        const pl = (1 - t) * 26 * Math.sin(Math.min(1, t * 5) * 1.57);
        g.strokeStyle = `rgb(${col[0] + rand() * 30},${col[1] + rand() * 20},${col[2]})`;
        g.lineWidth = 3.2;
        for (const sd of [-1, 1]) {
          g.beginPath(); g.moveTo(nx, ny);
          g.lineTo(nx + Math.cos(a + sd * 1.25) * pl, ny + Math.sin(a + sd * 1.25) * pl);
          g.stroke();
        }
        a += (a0 < -Math.PI / 2 ? -1 : 1) * 0.035;
        x = nx; y = ny;
      }
    }
  }, false);
}

function woodTexture(rand) {
  return canvasTexture(256, 256, (g, s) => {
    g.fillStyle = '#6a5238';
    g.fillRect(0, 0, s, s);
    for (let i = 0; i < 500; i++) {
      const y = rand() * s;
      g.strokeStyle = rand() < 0.5 ? `rgba(40,28,16,${0.1 + rand() * 0.3})` : `rgba(150,125,90,${0.08 + rand() * 0.2})`;
      g.lineWidth = 0.6 + rand() * 2;
      g.beginPath();
      g.moveTo(0, y);
      g.bezierCurveTo(s * 0.3, y + (rand() - 0.5) * 6, s * 0.6, y + (rand() - 0.5) * 6, s, y + (rand() - 0.5) * 4);
      g.stroke();
    }
    for (let i = 0; i < 5; i++) {
      g.fillStyle = 'rgba(30,20,12,0.5)';
      g.beginPath();
      g.ellipse(rand() * s, rand() * s, 7 + rand() * 6, 3 + rand() * 3, 0, 0, Math.PI * 2);
      g.fill();
    }
  }, true);
}

// ---------- Géométrie des arbres ----------

function newGeo() { return { pos: [], nor: [], uv: [], idx: [] }; }

function toBuffer(g) {
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(g.pos, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(g.nor, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(g.uv, 2));
  geo.setIndex(g.idx);
  return geo;
}

const _a = new V3(), _bx = new V3(), _bz = new V3(), _ax = new V3();

function addTube(g, p0, p1, r0, r1, radial, v0, v1) {
  _ax.subVectors(p1, p0).normalize();
  _a.set(0, 1, 0);
  if (Math.abs(_ax.y) > 0.99) _a.set(1, 0, 0);
  _bx.crossVectors(_ax, _a).normalize();
  _bz.crossVectors(_ax, _bx).normalize();
  const base = g.pos.length / 3;
  for (let ring = 0; ring < 2; ring++) {
    const c = ring ? p1 : p0, r = ring ? r1 : r0, v = ring ? v1 : v0;
    for (let i = 0; i <= radial; i++) {
      const an = (i / radial) * Math.PI * 2, cs = Math.cos(an), sn = Math.sin(an);
      const nx = _bx.x * cs + _bz.x * sn, ny = _bx.y * cs + _bz.y * sn, nz = _bx.z * cs + _bz.z * sn;
      g.pos.push(c.x + nx * r, c.y + ny * r, c.z + nz * r);
      g.nor.push(nx, ny, nz);
      g.uv.push((i / radial) * 2, v);
    }
  }
  for (let i = 0; i < radial; i++) {
    const a = base + i, b = a + 1, c = base + radial + 1 + i, d = c + 1;
    g.idx.push(a, b, c, b, d, c);
  }
}

function addCard(g, p, dir, size) {
  // deux quads croisés, alignés sur la direction de la branche
  _ax.copy(dir).normalize();
  _a.set(0, 1, 0);
  if (Math.abs(_ax.y) > 0.95) _a.set(1, 0, 0);
  _bx.crossVectors(_ax, _a).normalize();
  _bz.crossVectors(_ax, _bx).normalize();
  for (const side of [_bx, _bz]) {
    const base = g.pos.length / 3;
    const hw = size * 0.5;
    const pts = [
      [p.x - side.x * hw, p.y - side.y * hw, p.z - side.z * hw, 0, 0],
      [p.x + side.x * hw, p.y + side.y * hw, p.z + side.z * hw, 1, 0],
      [p.x + side.x * hw + _ax.x * size, p.y + side.y * hw + _ax.y * size, p.z + side.z * hw + _ax.z * size, 1, 1],
      [p.x - side.x * hw + _ax.x * size, p.y - side.y * hw + _ax.y * size, p.z - side.z * hw + _ax.z * size, 0, 1],
    ];
    for (const q of pts) {
      g.pos.push(q[0], q[1], q[2]);
      g.nor.push(0, 1, 0);
      g.uv.push(q[3], q[4]);
    }
    g.idx.push(base, base + 1, base + 2, base, base + 2, base + 3, base, base + 2, base + 1, base, base + 3, base + 2);
  }
}

// Arbre nu d'hiver. detail = profondeur maximale des branches.
function makeTree(seed, detail) {
  const rand = makeRng(seed);
  const wood = newGeo(), twigs = newGeo();
  const radials = [8, 6, 5, 3];
  const height = 9 + rand() * 4;
  const baseR = 0.24 + rand() * 0.16;

  const branch = (p, dir, len, r, depth) => {
    const segs = depth === 0 ? 5 : depth >= 3 ? 1 : 2;
    const rEnd = r * (depth === 0 ? 0.5 : 0.45);
    let cur = p.clone();
    const d = dir.clone().normalize();
    let v = 0;
    const forks = [];
    for (let s = 0; s < segs; s++) {
      const t0 = s / segs, t1 = (s + 1) / segs;
      const bend = depth === 0 ? 0.06 : 0.22;
      d.x += (rand() - 0.5) * bend; d.z += (rand() - 0.5) * bend;
      if (depth > 0) d.y += 0.06;
      d.normalize();
      const nxt = cur.clone().addScaledVector(d, len / segs);
      let r0 = r + (rEnd - r) * t0, r1 = r + (rEnd - r) * t1;
      if (depth === 0 && s === 0) r0 *= 1.45; // empattement
      const vl = (len / segs) / 2.2;
      addTube(wood, cur, nxt, r0, r1, radials[Math.min(depth, 3)], v, v + vl);
      v += vl;
      if (depth === 0 && t1 > 0.42 && t1 < 1) forks.push({ p: nxt.clone(), r: r1 });
      cur = nxt;
    }
    const spawn = (at, rr, n, lenK) => {
      for (let i = 0; i < n; i++) {
        const an = rand() * Math.PI * 2;
        const up = depth === 0 ? 0.5 + rand() * 0.5 : 0.25 + rand() * 0.5;
        const nd = new V3(Math.cos(an), up, Math.sin(an)).normalize().lerp(d, depth === 0 ? 0.15 : 0.45).normalize();
        if (depth + 1 > detail) {
          addCard(twigs, at, nd, (detail <= 1 ? 3.4 : 1.9) * (0.75 + rand() * 0.5));
        } else {
          branch(at, nd, len * lenK * (0.8 + rand() * 0.4), rr * 0.62, depth + 1);
        }
      }
    };
    if (depth === 0) {
      for (const f of forks) spawn(f.p, f.r, 1 + ((rand() * 2) | 0), 0.42);
      spawn(cur, rEnd * 1.3, 3, 0.4);
    } else {
      spawn(cur, rEnd * 1.4, depth >= 2 ? 2 : 2 + ((rand() * 2) | 0), 0.62);
    }
  };
  branch(new V3(0, -0.3, 0), new V3((rand() - 0.5) * 0.08, 1, (rand() - 0.5) * 0.08), height, baseR, 0);
  return { wood: toBuffer(wood), twigs: toBuffer(twigs), baseR, height };
}

// ---------- Mirador ----------

function makeStand(woodMat, withHunter) {
  const g = new THREE.Group();
  const box = (w, h, d, x, y, z) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), woodMat);
    m.position.set(x, y, z);
    m.castShadow = true;
    m.receiveShadow = true;
    g.add(m);
    return m;
  };
  const S = 1.1;
  box(2.3, 0.08, 2.3, 0, 2.8, 0); // plancher
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) box(0.12, 3.5, 0.12, sx * S, 1.75, sz * S);
  for (const s of [-1, 1]) {
    box(2.3, 0.07, 0.09, 0, 3.44, s * S);
    box(0.09, 0.07, 2.3, s * S, 3.44, 0);
    box(2.2, 0.5, 0.03, 0, 3.12, s * S);
    box(0.03, 0.5, 2.2, s * S, 3.12, 0);
  }
  // échelle à l'arrière
  for (const sx of [-0.28, 0.28]) box(0.06, 2.9, 0.06, sx, 1.4, 1.35).rotation.x = -0.12;
  for (let i = 0; i < 7; i++) box(0.56, 0.04, 0.05, 0, 0.35 + i * 0.38, 1.52 - i * 0.045);
  if (withHunter) {
    const vest = new THREE.MeshStandardMaterial({ color: 0xff5a00, roughness: 0.9 });
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 0.5, 4, 8), vest);
    body.position.set(0, 3.5, 0);
    g.add(body);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 6), new THREE.MeshStandardMaterial({ color: 0x8a6a50, roughness: 1 }));
    head.position.set(0, 4.02, 0);
    g.add(head);
  }
  return g;
}

// ---------- Monde ----------

export function buildWorld(scene, renderer) {
  const rand = makeRng(20261112);
  const aniso = Math.min(8, renderer.capabilities.getMaxAnisotropy());

  // Ciel
  const sunDir = new V3(-0.82, 0.4, -0.22).normalize();
  const fogColor = new THREE.Color(0xb3b8b4);
  scene.fog = new THREE.FogExp2(fogColor, 0.0105);
  scene.background = fogColor;
  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(900, 32, 16),
    new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      uniforms: {
        sunDir: { value: sunDir },
        horizon: { value: fogColor },
        zenith: { value: new THREE.Color(0x6f8fb0) },
        sunCol: { value: new THREE.Color(0xffd9a0) },
      },
      vertexShader: 'varying vec3 vDir; void main(){ vDir = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
      fragmentShader: `
        uniform vec3 sunDir, horizon, zenith, sunCol; varying vec3 vDir;
        void main(){
          vec3 d = normalize(vDir);
          float h = clamp(d.y, 0.0, 1.0);
          vec3 c = mix(horizon, zenith, pow(h, 0.6));
          float s = max(dot(d, sunDir), 0.0);
          c += sunCol * (pow(s, 900.0) * 6.0 + pow(s, 40.0) * 0.5 + pow(s, 6.0) * 0.22);
          gl_FragColor = vec4(c, 1.0);
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }`,
    })
  );
  sky.frustumCulled = false;
  scene.add(sky);

  // Lumière
  const hemi = new THREE.HemisphereLight(0xc4d6e8, 0x54463a, 1.5);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xffdcae, 3.4);
  sun.position.copy(sunDir).multiplyScalar(150);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  const sc = sun.shadow.camera;
  sc.left = -62; sc.right = 62; sc.top = 62; sc.bottom = -62; sc.near = 20; sc.far = 320;
  sun.shadow.bias = -0.0004;
  sun.shadow.normalBias = 0.06;
  scene.add(sun);
  scene.add(sun.target);

  // Sol
  const gTex = groundTexture(rand);
  gTex.repeat.set(52, 52);
  gTex.anisotropy = aniso;
  const gGeo = new THREE.PlaneGeometry(460, 460, 150, 150);
  gGeo.rotateX(-Math.PI / 2);
  const gp = gGeo.attributes.position;
  const gcol = new Float32Array(gp.count * 3);
  for (let i = 0; i < gp.count; i++) {
    const x = gp.getX(i), z = gp.getZ(i);
    gp.setY(i, heightAt(x, z));
    const n = 0.5 + 0.5 * Math.sin(x * 0.07 + Math.sin(z * 0.05) * 2) * Math.cos(z * 0.06 + 1.7);
    const m = 0.5 + 0.5 * Math.sin(x * 0.19 + 3) * Math.sin(z * 0.23);
    const v = 0.62 + 0.36 * n;
    gcol[i * 3] = v * (1 - 0.12 * m);
    gcol[i * 3 + 1] = v * (1 + 0.05 * m);
    gcol[i * 3 + 2] = v * (1 - 0.18 * m);
  }
  gGeo.setAttribute('color', new THREE.BufferAttribute(gcol, 3));
  gGeo.computeVertexNormals();
  const ground = new THREE.Mesh(gGeo, new THREE.MeshStandardMaterial({ map: gTex, bumpMap: gTex, bumpScale: 0.8, roughness: 1, metalness: 0, vertexColors: true }));
  ground.receiveShadow = true;
  scene.add(ground);

  // Placement des arbres
  const trunks = [];
  const cell = 6, grid = new Map();
  const key = (x, z) => Math.floor(x / cell) + ',' + Math.floor(z / cell);
  const near = (x, z, d) => {
    const cx = Math.floor(x / cell), cz = Math.floor(z / cell);
    for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) {
      const l = grid.get(cx + i + ',' + (cz + j));
      if (l) for (const t of l) if (Math.hypot(t.x - x, t.z - z) < d) return true;
    }
    return false;
  };
  const allowed = (x, z) => {
    const r = Math.hypot(x, z);
    if (r < 7.5) return 0;
    if (Math.abs(z) < 4.5 && Math.abs(x) < 86) return 0; // layon de la ligne de tir
    for (const n of NEIGHBOURS) if (Math.hypot(x - n.x, z - n.z) < 5) return 0;
    const e = ((x / 19) ** 2) + (((z + 36) / 30) ** 2); // clairière devant le poste
    if (e < 1) return 0.05;
    if (e < 1.7) return 0.45;
    return 1;
  };
  for (let i = 0; i < 9000 && trunks.length < 1500; i++) {
    const r = Math.sqrt(rand()) * 158, an = rand() * Math.PI * 2;
    const x = Math.cos(an) * r, z = Math.sin(an) * r;
    if (rand() > allowed(x, z)) continue;
    if (near(x, z, 3.4)) continue;
    const t = { x, z, s: 0.75 + rand() * 0.75, rot: rand() * Math.PI * 2, v: (rand() * 4) | 0, r: 0, h: 0 };
    trunks.push(t);
    const k = key(x, z);
    if (!grid.has(k)) grid.set(k, []);
    grid.get(k).push(t);
  }

  const bTex = barkTexture(rand);
  bTex.anisotropy = aniso;
  const barkMat = new THREE.MeshStandardMaterial({ map: bTex, bumpMap: bTex, bumpScale: 3, roughness: 1, metalness: 0 });
  const twigMat = new THREE.MeshStandardMaterial({ map: twigTexture(rand), alphaTest: 0.35, roughness: 1, metalness: 0 });
  const NEAR = 58;
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), p = new V3(), s = new V3();
  for (let v = 0; v < 4; v++) {
    const hi = makeTree(100 + v, 3), lo = makeTree(100 + v, 1);
    for (const far of [false, true]) {
      const list = trunks.filter((t) => t.v === v && (Math.hypot(t.x, t.z) > NEAR) === far);
      if (!list.length) continue;
      const src = far ? lo : hi;
      const wood = new THREE.InstancedMesh(src.wood, barkMat, list.length);
      const twigs = new THREE.InstancedMesh(src.twigs, twigMat, list.length);
      list.forEach((t, i) => {
        e.set((rand() - 0.5) * 0.06, t.rot, (rand() - 0.5) * 0.06);
        q.setFromEuler(e);
        p.set(t.x, heightAt(t.x, t.z), t.z);
        s.set(t.s, t.s * (0.9 + rand() * 0.25), t.s);
        m4.compose(p, q, s);
        wood.setMatrixAt(i, m4);
        twigs.setMatrixAt(i, m4);
        t.r = src.baseR * t.s * 1.15;
        t.h = src.height * s.y;
      });
      wood.castShadow = !far;
      twigs.castShadow = !far;
      wood.receiveShadow = true;
      wood.frustumCulled = false;
      twigs.frustumCulled = false;
      scene.add(wood, twigs);
    }
  }

  // Perches (jeunes arbres fins)
  {
    const g = newGeo();
    addTube(g, new V3(0, -0.2, 0), new V3(0.05, 3.5, 0.03), 0.045, 0.03, 5, 0, 2);
    addTube(g, new V3(0.05, 3.5, 0.03), new V3(-0.04, 7, 0.08), 0.03, 0.008, 5, 2, 4);
    addCard(g, new V3(0.02, 4.2, 0.04), new V3(0.1, 1, 0), 0.01);
    const geo = toBuffer(g);
    const N = 900;
    const poles = new THREE.InstancedMesh(geo, barkMat, N);
    let n = 0;
    for (let i = 0; i < 6000 && n < N; i++) {
      const r = 6 + Math.sqrt(rand()) * 125, an = rand() * Math.PI * 2;
      const x = Math.cos(an) * r, z = Math.sin(an) * r;
      if (rand() > allowed(x, z)) continue;
      e.set((rand() - 0.5) * 0.2, rand() * 6.3, (rand() - 0.5) * 0.2);
      q.setFromEuler(e);
      const k = 0.6 + rand() * 0.9;
      p.set(x, heightAt(x, z), z);
      s.set(k, k, k);
      m4.compose(p, q, s);
      poles.setMatrixAt(n++, m4);
    }
    poles.count = n;
    poles.frustumCulled = false;
    scene.add(poles);
  }

  // Sous-bois : herbes sèches et fougères rousses
  const cards = (tex, count, w, h, rMax, tint) => {
    const g = newGeo();
    for (let c = 0; c < 2; c++) {
      const an = c * Math.PI * 0.5 + 0.3, dx = Math.cos(an) * w * 0.5, dz = Math.sin(an) * w * 0.5;
      const b = g.pos.length / 3;
      g.pos.push(-dx, 0, -dz, dx, 0, dz, dx, h, dz, -dx, h, -dz);
      g.nor.push(0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0);
      g.uv.push(0, 0, 1, 0, 1, 1, 0, 1);
      g.idx.push(b, b + 1, b + 2, b, b + 2, b + 3, b, b + 2, b + 1, b, b + 3, b + 2);
    }
    const mat = new THREE.MeshStandardMaterial({ map: tex, alphaTest: 0.4, roughness: 1, metalness: 0, color: tint });
    const mesh = new THREE.InstancedMesh(toBuffer(g), mat, count);
    let n = 0;
    for (let i = 0; i < count * 4 && n < count; i++) {
      const r = 3 + Math.sqrt(rand()) * rMax, an = rand() * Math.PI * 2;
      const x = Math.cos(an) * r, z = Math.sin(an) * r;
      const patch = Math.sin(x * 0.11 + 2) * Math.cos(z * 0.09) + Math.sin(x * 0.31) * 0.4;
      if (patch < -0.15 && rand() < 0.8) continue;
      q.setFromAxisAngle(V3.prototype.set.call(p, 0, 1, 0), rand() * 6.3);
      const k = 0.6 + rand() * 0.9;
      s.set(k, k * (0.7 + rand() * 0.6), k);
      p.set(x, heightAt(x, z) - 0.03, z);
      m4.compose(p, q, s);
      mesh.setMatrixAt(n++, m4);
    }
    mesh.count = n;
    mesh.receiveShadow = true;
    mesh.frustumCulled = false;
    scene.add(mesh);
  };
  cards(grassTexture(rand), 5500, 0.9, 0.6, 85, 0xffffff);
  cards(fernTexture(rand), 1500, 1.5, 0.95, 95, 0xffffff);

  // Miradors
  const wTex = woodTexture(rand);
  const woodMat = new THREE.MeshStandardMaterial({ map: wTex, roughness: 0.95, metalness: 0 });
  scene.add(makeStand(woodMat, false));
  for (const n of NEIGHBOURS) {
    const st = makeStand(woodMat, true);
    st.position.set(n.x, heightAt(n.x, n.z), n.z);
    scene.add(st);
  }

  // Repoussement par les troncs (pour les animaux)
  const pushOut = (pos, radius) => {
    const cx = Math.floor(pos.x / cell), cz = Math.floor(pos.z / cell);
    for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) {
      const l = grid.get(cx + i + ',' + (cz + j));
      if (!l) continue;
      for (const t of l) {
        const dx = pos.x - t.x, dz = pos.z - t.z, d = Math.hypot(dx, dz), min = t.r + radius;
        if (d < min && d > 1e-4) {
          pos.x = t.x + (dx / d) * min;
          pos.z = t.z + (dz / d) * min;
        }
      }
    }
  };

  // Distance à laquelle une balle rencontre un tronc ou le sol
  const rayBlock = (o, d, maxDist) => {
    let best = maxDist, kind = 'none';
    const a = d.x * d.x + d.z * d.z;
    if (a > 1e-8) {
      for (const t of trunks) {
        const ox = o.x - t.x, oz = o.z - t.z;
        const b = ox * d.x + oz * d.z, c = ox * ox + oz * oz - t.r * t.r;
        const disc = b * b - a * c;
        if (disc < 0) continue;
        const tt = (-b - Math.sqrt(disc)) / a;
        if (tt <= 0 || tt >= best) continue;
        const y = o.y + d.y * tt, gy = heightAt(t.x, t.z);
        if (y > gy - 0.3 && y < gy + t.h) { best = tt; kind = 'tree'; }
      }
    }
    for (let tt = 1; tt < best; tt += 0.75) {
      if (o.y + d.y * tt < heightAt(o.x + d.x * tt, o.z + d.z * tt)) { best = tt; kind = 'ground'; break; }
    }
    return { dist: best, kind };
  };

  return { trunks, sun, sunDir, pushOut, rayBlock };
}
